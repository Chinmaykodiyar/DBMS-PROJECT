const WildCard = () => {
  return <h1 className="pt-[200px]">Data Not Found</h1>;
};
export default WildCard;
